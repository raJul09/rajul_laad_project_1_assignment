from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404
from .models import Product, Order
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse
from .forms import LoginForm, RegisterForm


# Home Page View
def home(request):
    products = Product.objects.all()
    return render(request, 'store/home.html', {'products': products})

def product_detail(request, product_id):
    # Fetch the product by its ID
    product = get_object_or_404(Product, id=product_id)
    return render(request, 'store/product_detail.html', {'product': product})

def product_list(request):
    products = Product.objects.all()  # Fetch all products from the database
    return render(request, 'store/product_list.html', {'products': products})

# Shopping Cart Page View
def cart(request):
    # Dummy cart functionality
    return render(request, 'store/cart.html')

# Checkout Page View
@login_required
def checkout(request):
    if request.method == 'POST':
        order = Order(user=request.user, total_price=100.00)  # dummy price
        order.save()
        return redirect('home')
    return render(request, 'store/checkout.html')



# User Registration View
def user_register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            # Create the new user
            user = form.save()
            messages.success(request, 'Registration successful. You can now log in.')
            return redirect('store:login')  # Redirect to login page after successful registration
    else:
        form = RegisterForm()
    
    return render(request, 'store/register.html', {'form': form})

# Login view
def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('store:home')  # Redirect to home page after login
            else:
                form.add_error(None, 'Invalid credentials')
    else:
        form = LoginForm()

    return render(request, 'store/login.html', {'form': form})

# Logout view
def user_logout(request):
    logout(request)
    return redirect('store:home')  # Redirect to home page after logout